<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('users')->updateOrInsert(
            ['email' => 'admin@kasir.local'],
            [
                'name' => 'admin',
                'password' => Hash::make('admin123'),
                'level' => 'admin',
                'created_at' => now(),
                'updated_at' => now(),
            ]
        );

        DB::table('produk')->insert([
            [
                'kode_produk' => 'PRD-001',
                'nama_produk' => 'Air Mineral',
                'kategori' => 'Minuman',
                'harga' => 5000,
                'stok' => 20,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'kode_produk' => 'PRD-002',
                'nama_produk' => 'Kopi Sachet',
                'kategori' => 'Minuman',
                'harga' => 3500,
                'stok' => 30,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
    }
}
