<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login - KasirKu</title>
</head>

<body>

    <h1>KasirKu</h1>

    <p>Sistem Informasi Kasir sederhana</p>

    <?php if(session('success')): ?>
        <p><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <p><?php echo e(session('error')); ?></p>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <p><?php echo e($errors->first()); ?></p>
    <?php endif; ?>

    <form method="POST" action="/login">
        <?php echo csrf_field(); ?>

        <div>
            <label>Username</label>
            <br>
            <input
                type="text"
                name="username"
                value="<?php echo e(old('username')); ?>"
                required
            >
        </div>

        <br>

        <div>
            <label>Password</label>
            <br>
            <input
                type="password"
                name="password"
                required
            >
        </div>

        <br>

        <button type="submit">Login</button>
    </form>

    <br>

    <p>
        Belum punya akun?
        <a href="/signup">Sign Up</a>
    </p>

   

</body>
</html><?php /**PATH C:\Users\HYPE AMD\Downloads\sistem_informasi_kasir_sederhana\HP-main\resources\views/login.blade.php ENDPATH**/ ?>