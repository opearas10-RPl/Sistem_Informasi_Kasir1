<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>

    <h1>Login</h1>

    <?php if(session('error')): ?>
        <p><?php echo e(session('error')); ?></p>
    <?php endif; ?>

    <form action="<?php echo e(url('/login')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <p>
            <label>Username:</label><br>
            <input type="text" name="username" required>
        </p>

        <p>
            <label>Password:</label><br>
            <input type="password" name="password" required>
        </p>

        <button type="submit">Login</button>
    </form>

    <p>
        Belum punya akun?
        <a href="<?php echo e(url('/signup')); ?>">Daftar di sini</a>
    </p>

</body>
</html><?php /**PATH C:\Users\HYPE AMD\Downloads\sistem_informasi_kasir_sederhana\Kasirku\resources\views/login.blade.php ENDPATH**/ ?>