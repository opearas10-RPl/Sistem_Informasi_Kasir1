<?php $__env->startSection('title', 'Dashboard - KasirKu'); ?>

<?php $__env->startSection('content'); ?>

    <h2>Dashboard</h2>

    <p>Selamat datang di Sistem Informasi Kasir.</p>

    <table border="1">
        <tr>
            <th>Keterangan</th>
            <th>Jumlah</th>
        </tr>
        <tr>
            <td>Total Produk</td>
            <td><?php echo e($totalProduk); ?></td>
        </tr>
        <tr>
            <td>Total Stok</td>
            <td><?php echo e($totalStok); ?></td>
        </tr>
    </table>

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HYPE AMD\Downloads\sistem_informasi_kasir_sederhana\Kasirku\resources\views/dashboard.blade.php ENDPATH**/ ?>