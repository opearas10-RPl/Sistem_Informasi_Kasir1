<h1>Data Produk</h1>

<p>Daftar data barang yang dijual.</p>

<a href="/produk/tambah">+ Input Data</a>

<br>
<br>

<table border="1">
    <thead>
        <tr>
            <th>No</th>
            <th>Kode</th>
            <th>Nama Produk</th>
            <th>Kategori</th>
            <th>Harga</th>
            <th>Stok</th>
            <th>Aksi</th>
        </tr>
    </thead>

    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($item->kode_produk); ?></td>
                <td><?php echo e($item->nama_produk); ?></td>
                <td><?php echo e($item->kategori ?: '-'); ?></td>
                <td>Rp <?php echo e(number_format($item->harga, 0, ',', '.')); ?></td>
                <td><?php echo e($item->stok); ?></td>

                <td>
                    <a href="/produk/<?php echo e($item->id); ?>/edit">Edit</a>

                    <form
                        action="/produk/<?php echo e($item->id); ?>"
                        method="POST"
                        style="display:inline;"
                        onsubmit="return confirm('Hapus data ini?')"
                    >
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>

                        <button type="submit">Hapus</button>
                    </form>
                </td>
            </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <tr>
                <td colspan="7">Belum ada data.</td>
            </tr>

        <?php endif; ?>
    </tbody>
</table>

<a href="/dashboard">Kembali</a>
<?php /**PATH C:\Users\HYPE AMD\Downloads\sistem_informasi_kasir_sederhana\HP-main\resources\views/produk.blade.php ENDPATH**/ ?>