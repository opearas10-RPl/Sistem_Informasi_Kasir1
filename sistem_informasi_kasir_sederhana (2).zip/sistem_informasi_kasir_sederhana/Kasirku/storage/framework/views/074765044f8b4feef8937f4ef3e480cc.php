
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Sistem Informasi Kasir'); ?></title>
</head>

<body>

    <h1>KasirKu</h1>

    <?php if(session()->has('user_id')): ?>
        <p>
            Selamat datang, <?php echo e(session('user_name')); ?>

        </p>

        <nav>
            <a href="<?php echo e(url('/dashboard')); ?>">Dashboard</a>
            |
            <a href="<?php echo e(url('/produk')); ?>">Data Produk</a>
            |
            <a href="<?php echo e(url('/produk/tambah')); ?>">Input Data Produk</a>
            |
            <a href="<?php echo e(url('/logout')); ?>">Logout</a>
        </nav>
    <?php else: ?>
        <nav>
            <a href="<?php echo e(url('/')); ?>">Login</a>
            |
            <a href="<?php echo e(url('/signup')); ?>">Daftar</a>
        </nav>
    <?php endif; ?>

    <hr>

    <?php if(session('success')): ?>
        <p><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <p><?php echo e(session('error')); ?></p>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>

</body>
</html>
<?php /**PATH C:\Users\HYPE AMD\Downloads\sistem_informasi_kasir_sederhana\Kasirku\resources\views/layout.blade.php ENDPATH**/ ?>