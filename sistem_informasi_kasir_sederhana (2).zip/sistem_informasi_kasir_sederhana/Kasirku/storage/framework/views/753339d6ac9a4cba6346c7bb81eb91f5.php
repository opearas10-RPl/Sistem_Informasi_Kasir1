<h1>Input Data Produk</h1>

<p>Isi data produk lalu simpan.</p>

<?php if($errors->any()): ?>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>

<form method="POST" action="/produk">
    <?php echo csrf_field(); ?>

    <div>
        <label>Kode Produk</label>
        <br>
        <input
            type="text"
            name="kode_produk"
            value="<?php echo e(old('kode_produk')); ?>"
            required
        >
    </div>

    <br>

    <div>
        <label>Nama Produk</label>
        <br>
        <input
            type="text"
            name="nama_produk"
            value="<?php echo e(old('nama_produk')); ?>"
            required
        >
    </div>

    <br>

    <div>
        <label>Kategori</label>
        <br>
        <input
            type="text"
            name="kategori"
            value="<?php echo e(old('kategori')); ?>"
        >
    </div>

    <br>

    <div>
        <label>Harga</label>
        <br>
        <input
            type="number"
            name="harga"
            min="0"
            value="<?php echo e(old('harga')); ?>"
            required
        >
    </div>

    <br>

    <div>
        <label>Stok</label>
        <br>
        <input
            type="number"
            name="stok"
            min="0"
            value="<?php echo e(old('stok', 0)); ?>"
            required
        >
    </div>

    <br>

    <a href="/produk">Batal</a>
    <button type="submit">Simpan</button>
</form>


<?php /**PATH C:\Users\HYPE AMD\Downloads\sistem_informasi_kasir_sederhana\Kasirku\resources\views/tambah_produk.blade.php ENDPATH**/ ?>