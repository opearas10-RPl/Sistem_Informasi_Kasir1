<h1>Edit Data Produk</h1>

<p>Ubah data produk, lalu simpan perubahan.</p>

<form method="POST" action="/produk/<?php echo e($produk->id); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div>
        <label>Kode Produk</label>
        <br>
        <input
            type="text"
            name="kode_produk"
            value="<?php echo e(old('kode_produk', $produk->kode_produk)); ?>"
            required
        >
    </div>

    <br>

    <div>
        <label>Nama Produk</label>
        <br>
        <input
            type="text"
            name="nama_produk"
            value="<?php echo e(old('nama_produk', $produk->nama_produk)); ?>"
            required
        >
    </div>

    <br>

    <div>
        <label>Kategori</label>
        <br>
        <input
            type="text"
            name="kategori"
            value="<?php echo e(old('kategori', $produk->kategori)); ?>"
        >
    </div>

    <br>

    <div>
        <label>Harga</label>
        <br>
        <input
            type="number"
            name="harga"
            min="0"
            value="<?php echo e(old('harga', $produk->harga)); ?>"
            required
        >
    </div>

    <br>

    <div>
        <label>Stok</label>
        <br>
        <input
            type="number"
            name="stok"
            min="0"
            value="<?php echo e(old('stok', $produk->stok)); ?>"
            required
        >
    </div>

    <br>

    <a href="/produk">Batal</a>
    <button type="submit">Simpan Perubahan</button>

</form>

<?php /**PATH C:\Users\HYPE AMD\Downloads\sistem_informasi_kasir_sederhana\Kasirku\resources\views/edit_produk.blade.php ENDPATH**/ ?>