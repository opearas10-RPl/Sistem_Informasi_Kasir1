
@extends('layout')

@section('title', 'Dashboard - KasirKu')

@section('content')

    <h2>Dashboard</h2>

    <p>Selamat datang di Sistem Informasi Kasir.</p>

    <table border="1">
        <tr>
            <th>Keterangan</th>
            <th>Jumlah</th>
        </tr>
        <tr>
            <td>Total Produk</td>
            <td>{{ $totalProduk }}</td>
        </tr>
        <tr>
            <td>Total Stok</td>
            <td>{{ $totalStok }}</td>
        </tr>
    </table>

    

@endsection
