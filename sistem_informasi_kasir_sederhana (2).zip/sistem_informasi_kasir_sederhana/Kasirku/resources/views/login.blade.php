<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>

    <h1>Login</h1>

    @if(session('error'))
        <p>{{ session('error') }}</p>
    @endif

    <form action="{{ url('/login') }}" method="POST">
        @csrf

        <p>
            <label>Username:</label><br>
            <input type="text" name="username" required>
        </p>

        <p>
            <label>Password:</label><br>
            <input type="password" name="password" required>
        </p>

        <button type="submit">Login</button>
    </form>

    <p>
        Belum punya akun?
        <a href="{{ url('/signup') }}">Daftar di sini</a>
    </p>

</body>
</html>