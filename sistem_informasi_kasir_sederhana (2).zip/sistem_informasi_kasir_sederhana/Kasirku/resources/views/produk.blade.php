<h1>Data Produk</h1>

<p>Daftar data barang yang dijual.</p>

<a href="/produk/tambah">+ Input Data</a>

<br>
<br>

<table border="1">
    <thead>
        <tr>
            <th>No</th>
            <th>Kode</th>
            <th>Nama Produk</th>
            <th>Kategori</th>
            <th>Harga</th>
            <th>Stok</th>
            <th>Aksi</th>
        </tr>
    </thead>

    <tbody>
        @forelse($produk as $item)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $item->kode_produk }}</td>
                <td>{{ $item->nama_produk }}</td>
                <td>{{ $item->kategori ?: '-' }}</td>
                <td>Rp {{ number_format($item->harga, 0, ',', '.') }}</td>
                <td>{{ $item->stok }}</td>

                <td>
                    <a href="/produk/{{ $item->id }}/edit">Edit</a>

                    <form
                        action="/produk/{{ $item->id }}"
                        method="POST"
                        style="display:inline;"
                        onsubmit="return confirm('Hapus data ini?')"
                    >
                        @csrf
                        @method('DELETE')

                        <button type="submit">Hapus</button>
                    </form>
                </td>
            </tr>

        @empty

            <tr>
                <td colspan="7">Belum ada data.</td>
            </tr>

        @endforelse
    </tbody>
</table>

<a href="/dashboard">Kembali</a>
